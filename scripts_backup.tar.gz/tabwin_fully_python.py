from pykeyboard import PyKeyboard
from pymouse import PyMouseEvent
from getch import GetchUnix
import threading
import os

keyboard = PyKeyboard()
keyboard.press_key(keyboard.alt_key)
keyboard.tap_key(keyboard.tab_key)

getch = GetchUnix()

class KeypressListener(threading.Thread):

	def run(self):
		while True:
			key = getch()

			if ord(key) == 13 or ord(key) == 27: 
				keyboard.release_key(keyboard.alt_key)
				break

class Click(PyMouseEvent):

	def __init__(self):
		PyMouseEvent.__init__(self)
		KeypressListener().start()

	def click(self, x, y, button, press):
		
		if button == 1:
			keyboard.release_key(keyboard.alt_key)
			self.stop()

Click().run()