xfce4-terminal --drop-down # -e "tmux new-session -n -d 'ncmpcpp'"
#xdotool key 8
xdotool keydown ctrl keydown b keydown shift key 5
xdotool keyup ctrl keyup b keyup shift
#xdotool key 8 & ncmpcpp
xdotool key n + c + m + p + c + p + p
xdotool key Return
xdotool key 8
