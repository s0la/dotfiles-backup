#!/bin/bash

xfce4-terminal --drop-down && tmux send c-l c-l ^h ^h ^h ENTER $1
