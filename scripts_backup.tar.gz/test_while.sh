#!/bin/bash

bg="%{B#333}"
fg="%{F#909090}"
all_windows="$bg$fg%{U#9bb73c}"

active_desktop=$(xdotool get_desktop)
desktop_count=$(xdotool get_num_desktops)
active_id=$(printf 0x%x $(xdotool getactivewindow))

readarray -t windows <<< "$(wmctrl -l | awk '$2 != '-1' { print }' | sort -n -k 2)"

for desktop in $(seq 0 $((desktop_count - 1))); do
	[[ $desktop -eq $active_desktop ]] && bg="%{B#404040}" || bg="%{B#333}"
	all_windows+="$bg"

	while true; do
		window="$(echo ${windows[$index]} | awk '$2 == '$desktop' { print }')"
		if [[ $window ]]; then
			window_id=${window%% *}
			window_name="%{O20}${window#*$(hostname)}%{O20}"

			[[ ${#window_name} -gt 35 ]] && window_name="${window_name::25}..%{O20}"
			#[[ ${#window_name} -gt 20 ]] && window_name="%{A:wmctrl -i -a $window_id:}%{O20}${window_name::18}..%{O20}%{A}"
			[[ ${window%% *} =~ ${active_id#0x} ]] && window_name="%{+u}%{B#4a4a4a}$window_name$bg%{-u}"
			#echo "${window%% *} $active_id"

			all_windows+="%{A:wmctrl -i -a $window_id:}$window_name%{A}"

			(( index++ ))
		else
			break
		fi
	done

	[[ $index -ne $last_index ]] && all_windows+="%{B#00000000}%{O5}"
	last_index=$index
done

echo -e "%{c}$all_windows"
