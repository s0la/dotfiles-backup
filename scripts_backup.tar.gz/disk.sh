#!/bin/bash

count=0

#for dev in ; do
#	((count++))
#	#read dev space <<< "$(echo "$dev")"
#
#	echo "$dev  $count"
#done
disks=""

while read -r line; do
	read dev space free <<< "$(echo $line)"
	((${space%*%} > 95)) && space="%{F#875651}$free%{F-}"
	disks+="${dev##*/}  $space    "
done <<< "$(df -h | awk '/sda/ {print $1 " " $5 " " $4}')"

echo $disks
