#!/bin/bash

modis+="window,run,"
modis+="sola:~/Desktop/rofi_test.sh,"
modis+="workspaces:~/Desktop/rofi_workspaces.sh,"
modis+="move_to:~/Desktop/rofi_workspaces.sh move,"
modis+="media:~/Desktop/rofi_media.sh,"
modis+="mount:~/Desktop/rofi_mount.sh"
rofi -modi "$modis" -show sola
