displays=$(xrandr -q | grep ' connected')

for d in $(seq $(echo "$displays" | wc -l)); do
	declare display_$(((d % 2) + 1))="$(echo "$displays" | sed -n "$d"p | cut -d " " -f3 | cut -d "+" -f1)"
done

id=$(printf 0x%x $(xdotool getactivewindow))

function getProperty() {
        xwininfo -id $id | grep "$1" | cut -d ":" -f2 | grep -o '[^ ]*'
}

window_x=$(($(getProperty "Absolute upper-left X") - 1))
window_width=$(getProperty "Width")

farest_right_point=$((window_x + window_width))
start_left_point=0

for d in $(seq $(echo "$displays" | wc -l)); do
	display=display_$d
	resolution=$(echo ${!display})

	w=$((start_left_point + $(echo $resolution | cut -d 'x' -f1)))

	if [ $farest_right_point -le $w ]; then
		break
	else
		start_left_point=$w
	fi
done

screen_width=$(echo $resolution | cut -d 'x' -f1)
screen_height=$(echo $resolution | cut -d 'x' -f2)

if [ "$1" == "r" ]; then ((start_left_point+=$((screen_width / 2)))); fi

window_x=$(($(getProperty "Absolute upper-left X") - 1))
window_y=$(($(getProperty "Absolute upper-left Y") - 23))
window_width=$(getProperty "Width")
window_height=$(getProperty "Height")

if [ $window_height -lt $((screen_height - 100)) ]; then
	echo "wmctrl -ir $id -e 0,$window_x,$window_y,$window_width,$window_height" >> ~/Documents/original_properties.txt
	wmctrl -ir $id -e 0,$start_left_point,24,$((screen_width / 2)),$((screen_height - 30))
else
	$(grep $id ~/Documents/original_properties.txt)
	sed -i "/$id/d" ~/Documents/original_properties.txt

	if [ $(cat ~/Documents/original_properties.txt | wc -l) -eq 0 ]; then rm ~/Documents/original_properties.txt; fi
fi