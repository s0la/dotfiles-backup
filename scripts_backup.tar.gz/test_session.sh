#tmux new -s Session
#tmux neww win1 'ncmpcpp'
#split-window -v 'top'
#tmux attach

#!/bin/sh 
tmux new-session -d -s Music 'ncmpcpp'
tmux rename-window Music
tmux split-window -h -p 60 -t 1 ncmpcpp
tmux send-keys 8
tmux resize-pane -Z
#tmux select-pane -t 0
#tmux resize-pane -Z
#tmux split-window -v 'top'
#tmux neww -n win1 'ncmpcpp'
#tmux split-window -h 'top'
tmux  attach-session -d
