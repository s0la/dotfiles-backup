#xfconf-query -c xfce4-desktop -p /desktop-icons/style -s 0
#tint2 -c Desktop/fullscreeen_panel &
#sleep 0.1
#tint2 -c Desktop/fullscreeen_panel &
#kill $(pidof tint2 | cut -d ' ' -f1)
tint2 -c Desktop/workspace_switcher_background &
tint2 -c Desktop/workspace_switcher &
#sleep 0.005
#tint2 -c Desktop/fullscreeen_panel &
