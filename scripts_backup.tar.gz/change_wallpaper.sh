#!/bin/bash

function set_walls() {
	display_count=$(xrandr -q | grep ' connected' | wc -l)

	for display in $(seq $display_count); do
		walls+="$(eval $1) "
	done
}

function set_wall() {
	sed -i "s#.*$current_desktop.*#$current_desktop $walls#" ~/Desktop/walls.txt
	DISPLAY=:0 feh --bg-scale $walls
}

current_desktop=desktop_"$(xdotool get_desktop)"
#current_wall=$(sed -n "/$current_desktop/p" ~/Desktop/walls.txt | cut -d " " -f2)
current_wall=$(awk '/'$current_desktop'/ {print $2}' ~/Desktop/walls.txt)

if [[ -n $current_wall ]]; then
	case $1 in
		previous)
			if [ "$current_wall" == "$(ls ~/Downloads/setup/walls/*.jpg | head -n 1)" ]; then 
				set_walls "ls ~/Downloads/setup/walls/*.jpg | tail -n 1"
			else
				set_walls "ls ~/Downloads/setup/walls/*.jpg | grep -B1 $current_wall | head -n 1"
			fi
			;;
		next)
			if [ "$current_wall" == "$(ls ~/Downloads/setup/walls/*.jpg | tail -n 1)" ]; then 
				set_walls "ls ~/Downloads/setup/walls/*.jpg | head -n 1"
			else
				set_walls "ls ~/Downloads/setup/walls/*.jpg | grep -A1 $current_wall | tail -n 1"
			fi
			;;
		*)
			set_walls "ls ~/Downloads/setup/walls/*.jpg | sort -R | sed -n 1p"
			;;
	esac

	set_wall
	exit
fi
