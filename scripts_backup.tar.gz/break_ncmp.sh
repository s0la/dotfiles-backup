#!/bin/bash

xfce4-terminal --drop-down && tmux break-pane \; rename-window visualizer \; select-window -t songlist
