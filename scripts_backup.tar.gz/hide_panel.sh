Desktop/hide_drop_down.sh
Documents/scripts/general/sh/hide.sh 3
sleep 0.5
tint2 -c Desktop/config/tint2/main