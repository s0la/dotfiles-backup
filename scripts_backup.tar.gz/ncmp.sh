ncmpcpp &
sleep 1 &
xdotool key 8
