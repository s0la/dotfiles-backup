#!/bin/bash

if [ -z "$(tmux ls | grep music)" ]; then
	~/Desktop/create_session.sh
fi

tmux a -t music
