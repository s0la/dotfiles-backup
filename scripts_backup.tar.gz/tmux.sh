#/bin/bash

tmux new  -s test -n first ncmpcpp
tmux neww -n foo/bar foo
tmux splitw -v -p 50 -t 0 bar
tmux selectw -t 1 
tmux selectp -t 0