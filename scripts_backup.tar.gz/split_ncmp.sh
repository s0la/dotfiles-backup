#!/bin/bash

xfce4-terminal --drop-down && tmux send 1 c-l ^h ^h 33 ENTER 8
