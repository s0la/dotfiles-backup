#!/bin/bash

fifo="/home/sola/Desktop/fifo"

font1="consolas:size=11"
font2="IcoMoon:size=10"
font3="FontAwesome:size=9"
font4="Hack:size=14"
font5="Monaco:size=9"

media_beggining="%{B#00000000}%{F#333333}%{B#333333}"
media_ending="%{B#aa333333}%{F#333}%{T4}%{F#cecece}"

system_info_beggining="%{F#333}%{B#333}%{F#cecece}%{T1}"
system_info_ending="%{B#00000000}%{F#333}%{B#d9545454}"

song_info_index=0
song_info="not playing"

get_song_info() {
	status=$(mpc | sed -n 's/.*\[\(.*\)\].*/\1/p')
	if [[ "$status" == 'playing' ]]; then
		#if [[ $song_info ]]; then
			elapsed_time=$(mpc | awk -F '[ /]' 'NR == 2 {print $6}')
			song_info="$(mpc current -f "%artist% - %title% $elapsed_time/%time%")"
			#[[ ${elapsed_time#0} -lt 3 ]] && song_info_index=0 || ((song_info_index++))
			[[ ${elapsed_time:0:1} -eq 0 && ${elapsed_time: -2} -lt 3 ]] && song_info_index=0 || ((song_info_index++))

			echo -e "PROGRESSBAR $(~/Desktop/bar/song_progress.sh 3)"
			echo "SONG $(~/Desktop/bar/media.sh SONG "$song_info" $song_info_index)"
			#((song_info_index++))
		#fi
	fi

	echo -e "MEDIA_VOLUME $(~/Desktop/bar/media.sh VOLUME)"
	echo -e "BUTTONS $(~/Desktop/bar/media.sh BUTTONS)"
	echo -e "CONTROLS $(~/Desktop/bar/media.sh CONTROLS "$song_info" "$status" stop)"
}

workspace_count=$(wmctrl -d | wc -l)

get_workspaces() {
	echo -e "WORKSPACES $(~/Desktop/bar/workspaces.sh $workspace_count)"
}

get_mail() {
	echo -e "MAIL $(~/Desktop/bar/system_info.sh MAIL)"
}

get_volume() {
	echo -e "VOLUME $(~/Desktop/bar/system_info.sh VOLUME)"
}

get_network() {
	echo -e "NETWORK $(~/Desktop/bar/system_info.sh NETWORK)"
}

get_date() {
	echo -e "DATE $(~/Desktop/bar/system_info.sh DATE)"
}

shut_down() {
	echo -e "SHUT_DOWN $(~/Desktop/bar/system_info.sh SHUT_DOWN)" > "$fifo" &
}

while true; do get_song_info; sleep 1; done > "$fifo" &
while true; do get_workspaces; sleep 1; done > "$fifo" &
while true; do get_mail; sleep 10; done > "$fifo" &
while true; do get_volume; sleep 1; done > "$fifo" &
while true; do get_network; sleep 100; done > "$fifo" &
while true; do get_date; sleep 60; done > "$fifo" &
shut_down

while read -r line; do
	case $line in
		SONG*) song_info="${line:5}" ;;
		PROGRESSBAR*) progressbar="${line:12}" ;;
		CONTROLS*) controls="${line:9}" ;;
		MEDIA_VOLUME*) media_volume="${line:13}" ;;
		BUTTONS*) buttons="${line:7}" ;;
		WORKSPACES*) workspaces="${line:11}" ;;
		MAIL*) mail="${line:5}" ;;
		VOLUME*) volume="${line:7}" ;;
		NETWORK*) network="${line:8}" ;;
		DATE*) date="${line:5}";;
		SHUT_DOWN*) shut_down="${line:10}"
	esac

	media="%{B#333}  %{T5}$progressbar  %{F#777}%{T3}$controls%{O15}$song_info %{F#cecece}$media_volume$buttons$media_ending"
	workspaces="%{c}%{F#777}$workspaces"
	system_info="%{r}$system_info_beggining $mail$volume%{O30}$network%{O30}$date"
	echo -e "%{B#333}$media $workspaces $system_info $shut_down%{B#aa333333}"
done < "$fifo" | lemonbar -p -B#333 -f "$font1" -o -3 \
				    -f "$font2" -o -5 \
				    -f "$font3" -o -6 \
				    -f "$font4" -o -0 \
				    -f "$font5" -o -4 -a 55 -g x22 | bash 
