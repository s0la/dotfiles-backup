#!/bin/bash

function read_wall() {
	current_wall=$(sed -n "/desktop_$1/p" Desktop/walls.txt | cut -d " " -f2-)
}

current_desktop=$(xprop -root _NET_CURRENT_DESKTOP | tail -c -2)
read_wall $current_desktop

if [ -z $current_wall ]; then
	read_wall $((current_desktop - 1))

	if [ -z $current_wall ]; then
		read_wall 0
	fi

	echo "desktop_$current_desktop $current_wall" >> Desktop/walls.txt
fi

/usr/bin/feh --bg-scale $current_wall