#!/bin/bash
drop_down_id=$(wmctrl -l | grep "Terminal - Music")
xdotool windowminimize ${drop_down_id:0:10}