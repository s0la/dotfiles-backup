pkill tint2
Desktop/tints.sh
#Documents/scripts/workspaces_manager/sh/spread.sh 0
python Desktop/desk_files/spread_all_python.py
