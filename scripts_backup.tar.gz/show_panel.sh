pkill tint2
sleep 0.5
Desktop/toggle_music.sh
#sleep 0.5
Documents/scripts/general/sh/show.sh 3