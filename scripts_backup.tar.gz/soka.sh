#!/bin/bash

case $1 in
	soka*) echo "soka car najveci" > Desktop/soka ;;
esac
