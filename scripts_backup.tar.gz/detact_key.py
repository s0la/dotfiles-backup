from pykeyboard import PyKeyboard
from getch import GetchUnix
import threading

keyboard = PyKeyboard()
keyboard.press_key(keyboard.alt_key)
keyboard.tap_key(keyboard.tab_key)

getch = GetchUnix()

while True:
	key = getch()
	if ord(key) == 13 or ord(key) == 27:
		print "pressed"
		keyboard.release_key(keyboard.alt_key)
		break

