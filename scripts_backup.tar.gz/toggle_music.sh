if [ -z "$(tmux ls | grep Music)" ]; then
	echo 'creating..'
	#xfce4-terminal --drop-down -e Desktop/music.sh
	xfce4-terminal --drop-down -e "tmux new -s Music 'ncmpcpp'"
else
	echo 'attaching..'
	xfce4-terminal --drop-down -e 'tmux a -t Music'
fi
