test_func() {
	echo "this function is for testing purpose only ;)"

	read user_input
	echo "user inputed the following string: $user_input"
}

echo "starting script.."
test_func
