#xfce4-terminal --drop-down && tmux neww -n forth
xfce4-terminal --drop-down
#tmux join-pane -h -s nano -t first
tmux break-pane
tmux rename-window second
