#!/bin/bash

declare -A arr

while read -r line; do
	id=$(echo $line | awk '{print $2}')
	echo $id
	name="${line%% *} ${line#*$(hostname)}"
	arr[$id]=($name)
done <<< "$(wmctrl -l | awk '$2 != '-1' {print}')"

echo ${#arr[@]}

#for i in {0..3}; do
#
#done

for i in ${!arr[@]}; do
	echo "${arr[$i]}"
done
