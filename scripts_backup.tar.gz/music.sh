#xfce4-terminal --drop-down -x sh -c "tmux && xdotool key; bash"
#tmux
#xfce4-terminal --drop-down -e ""





#!/bin/sh 
#tmux new -s Music
tmux neww -n songlist 'ncmpcpp'
tmux neww -n visualizer 'ncmpcpp'
tmux a -t Music



#tmux -new -s Music
#tmux neww -n Songlist 'ncmpcpp'
#tmux neww -n Visualizer 'xdotool key 8 & ncmpcpp'

#tmux a -t 0
#tmux select-window -t 1:first

#tmux split-window -h -p 60 'xdotool key 8 & ncmpcpp'
#tmux send-key 8
#tmux selectp -t 0
#tmuc left-pane -d 'sleep 1;xdotool key 8; sleep 5'
#tmux -c 'sleep 1;xdotool key 8; sleep 5'
#tmux select-pane -t 0
#tmux -2 attach-session -d 

#sleep 2

#xdotool keydown 8 keyup 8