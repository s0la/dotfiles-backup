
#xfce4-terminal --drop-down -e 'tmux'

tmux new -s music 'ncmpcpp' \; \
neww -n new 'ncmpcpp' \; send-keys 2 \; \
split-window -h 'ncmpcpp' \; send-keys 5 \; \
select-pane -t 0 \; \
resize-pane -Z
#neww -n sola 'ncmpcpp' \; \
#split-window -h -p 70 'ncmpcpp' \; \
#send-keys 2 \; \
#select-pane -t 0 \; \
#resize-pane -Z
#rename-window 'songlist' \; \
#new-window -n 'visualizer' 'ncmpcpp' \; \
#send-keys 2