#!/bin/bash

while true; do
	media=$(~/Desktop/bar/media.sh
