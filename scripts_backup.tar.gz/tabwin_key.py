from pykeyboard import PyKeyboard
from pykeyboard import PyKeyboardEvent
from pymouse import PyMouseEvent
import os

keyboard = PyKeyboard()
keyboard.press_key(keyboard.alt_key)
keyboard.tap_key(keyboard.tab_key)

class Press(PyKeyboardEvent):

	def __init__(self):
		PyKeyboardEvent.__init__(self)

	# def key_press(self, keycode):

	# 	os.system('notify-send "hello"')

		# if keycode == self.lookup_character_value('Return'):
		# 	os.system('notify-send "hello :)"')
		# 	keyboard.release_key(keyboard.alt_key)
		# 	self.stop()

	def key_press(self, keycode):

		if keycode in self.mod_keycodes['Shift']:
			print 'shift'
		elif keycode in self.mod_keycodes['Alt']:
			print 'alt'
		else:
			pass

Press().run()