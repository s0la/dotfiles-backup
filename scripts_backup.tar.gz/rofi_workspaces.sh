#!/bin/bash

desks=( $(wmctrl -d | awk '{print $NF}') )

if [[ -z $@ || $@ = move ]]; then
	for desk in ${desks[*]}; do
		echo "$desk"
	done
else
	args="$@"
	desktop_name="${args##* }"
	desktop_id=$(wmctrl -d | awk '/'$desktop_name'/ {print $1}')
	#[[ $args =~ move ]] && command='-r :ACTIVE: -t' || command='-s'
	#wmctrl $command $desktop_id
	#[[ $args =~ move ]] && wmctrl -r :ACTIVE: -t $desktop_id
	#wmctrl -s $desktop_id
	active_window_id=$(printf 0x%x $(xdotool getactivewindow))
	wmctrl -s $desktop_id
	[[ $args =~ move ]] && wmctrl -i -R $active_window_id
fi
