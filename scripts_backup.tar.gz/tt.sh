tmux new -s sess -d
tmux splitw -h ncmpcpp
tmux respawnp -t .- -k 'notify-send "pane respawned"'
tmux a -t sess
