#!/bin/bash

echo "${@## *}"
