#!/bin/bash

var="$@"
echo "${$@##* }"
