#!/bin/bash

xfce4-terminal --drop-down && tmux join-pane -h -p 73 -s visualizer -t songlist
