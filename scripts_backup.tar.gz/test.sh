#!/bin/bash

current_desk=$(xprop -root _NET_CURRENT_DESKTOP | tail -c -2)

while read -r line; do
	#proprs=( $(echo $line | awk '{print $3" "$4" "$5" "$6}') )
	#echo ${proprs[*]}
	var+=("$(echo $line | awk '{print $1" "$3" "$4" "$5" "$6}')")
done <<< "$(wmctrl -l -G | awk '$2 == '$current_desk'')"

for win in "${var[@]}"; do
	[[ $win =~ 0x026 ]] && echo ${win#* }
done
