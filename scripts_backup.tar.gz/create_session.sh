#!/bin/bash

tmux new -d -s music 'ncmpcpp -c Downloads/config'
tmux rename-window songlist
tmux neww -n visualizer 'ncmpcpp -c Downloads/config'
tmux send 8 ENTER
tmux previous-window
