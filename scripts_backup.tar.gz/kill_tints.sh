#pkill tint2
#xfconf-query -c xfce4-desktop -p /desktop-icons/style -s 2
ids=$(pidof tint2)
kill ${ids% *}
#tint2 -c Desktop/config/tint2/main &
