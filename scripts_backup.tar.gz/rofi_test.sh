#!/bin/bash

if [[ -z $@ ]]; then
	echo -e 'sola\nthunar\nminimize\nmaximize\nfit screen\nforce fit screen'
else
	command=$@

	case $command in
		sola*) notify-send "sola car" ;;
		thunar*) thunar Desktop ;;
		fit*) ~/Desktop/fit_window_second_gen_fixed.sh ;;
		force*) ~/Desktop/fit_window_second_gen_fixed.sh force ;;
		min*) xdotool getactivewindow windowminimize ;;
		max*) wmctrl -r :ACTIVE: -b toggle,maximized_vert,maximized_horz ;;
	esac
fi
