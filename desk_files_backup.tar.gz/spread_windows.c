#include<stdio.h>
#include<stdlib.h>


int getIntFromCommand(FILE *command) {

	char line[2];
	int size;

	while(fgets(line, 2, command) != NULL) {

	 	sscanf (line, "%d", &size);
   }

   return size;
}

char *getWindowId(char line[]) {

	char *id;

	id = malloc(10 * sizeof(char));

	for (int i = 0; i < 10; i++) {
		id[i] = line[i];
	}

	return id;
}

void printArray(char *array[], size_t size) {
	for(int i = 0; i < size; i++) {
		printf("%s\n", array[i]);
	}
}

int countStringSize(char *stringToCount) {
	int count = 0;

	while(stringToCount[count] != '\0') count++;

	return count;
}

char *getStringCommand(char *rawCommand, char specifiedDesktop, int position) {
	int size = countStringSize(rawCommand);
	char *validCommand = malloc((size + 1) * sizeof(char*));

	for(int count = 0; count < size; count++) {
		if(count == size - position) {
			validCommand[count] = specifiedDesktop;
			validCommand[count + 1] = rawCommand[count++];
		} else {
			validCommand[count] = rawCommand[count];
		}
	}

	return validCommand;
}

int getSpecifiedValue(char *argv[], int current) {
	if (argv[1] != NULL) {
		return *argv[1] - '0';
	} else {
		return 0;
	}
}

int getWindowsCountOfSpecifiedDesktop(char specified) {
	char *windows = "wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | grep '^.\\{12\\}' | wc -l";
	char *command = getStringCommand(windows, specified, 9);

	FILE *windowsCountCommand = popen(command, "r");

	int windowsCount = getIntFromCommand(windowsCountCommand);

	//fclose(windowsCountCommand);

	return windowsCount;
}

char **populateArray(char specified) {
	char *windows = "wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | grep '^.\\{12\\}'";
	char *command = getStringCommand(windows, specified, 1);
	char buffer[200];

	int size = getWindowsCountOfSpecifiedDesktop(specified);
	int count = 0;

	char **arrayToReturn = malloc(size * sizeof(char*));

	FILE *windowsIds = popen(command, "r");

	while(fgets(buffer, 200, windowsIds)) {
	 	arrayToReturn[count++] = getWindowId(buffer);
    }

    fclose(windowsIds);

	return arrayToReturn;
}

int getCurrentDesktop() {
	FILE *currentDesktopCommand = popen("wmctrl -d | grep '*' | cut -c 1", "r");
	int currentDesktop = getIntFromCommand(currentDesktopCommand);
	
	fclose(currentDesktopCommand);

	return currentDesktop;
}

char *getValueFromCommand(FILE *command) {
	//fseek(command, 0L, SEEK_END);
	//int size = ftell(command);
	char *value = malloc(4 * sizeof(char));

	fread(value, sizeof(char), 4, command);

	printf("%s\n", value);

	return "";
}

char *getXCommand(char *command, char *id) {
	char finalCommand[countStringSize(command) + countStringSize(id)];

	sprintf(finalCommand, command, id);

	printf("%s\n", finalCommand);

	FILE *commandToExecute = popen(finalCommand, "r");

	printf("%s\n", getValueFromCommand(commandToExecute));
}

void printParametars(char *id) {
	FILE *xCommand = popen("xwininfo -id $1 | grep 'Absolute upper-left X:' | grep -Eo '(-?[0-9]+)'", "r");
}

int getMultiplier(int base, int multiplier) {
	int result = 1;

	while(multiplier > 0) {
		result *= base;
		multiplier--;
	}

	return result;
}

int stringToInt(char *string) {
	int size = countStringSize(string);
	int sum = 0;

	for(int index = 0; size > 0; index++) {
		int muptilpier = getMultiplier(10, --size);
		int digit = string[index] - '0';

		sum += digit * muptilpier;
	}

	return sum;
}

int main(int argc, char *argv[]) {
	int current = getCurrentDesktop();
	int specified = getSpecifiedValue(argv, current);

    int wNum = getWindowsCountOfSpecifiedDesktop(specified + '0');

    char **arr = populateArray(specified + '0');

    for(int i = 0; i < wNum; i++) {
    	printf("%s\n", arr[i]);
    	//printf("wmctrl -i -r %s -e 0,x,x,x,x\n", arr[i]);
    	getXCommand("xwininfo -id %s | grep 'Absolute upper-left X:' | grep -Eo '(-?[0-9]+)'", arr[i]);
    }

    int a = stringToInt("429");
    printf("%d\n", a);
}