#include<stdio.h>

int main() {
	FILE *f = fopen("/home/sola/Desktop/file_to_append_to.txt", "a");
	fprintf(f, "%s\n", "2nd line string :)");
	fclose(f);
}