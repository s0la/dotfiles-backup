#include<stdio.h>
#include<stdlib.h>


int getWindowsNumber(FILE *w) {

	char line[2];
	int size;

	while(fgets(line, 2, w) != NULL) {

	 	sscanf (line, "%d", &size);
   }

   return size;
}

char *getWindowId(char line[]) {

	char *id;

	id = malloc(10 * sizeof(char));

	for (int i = 0; i < 10; i++) {
		id[i] = line[i];
	}

	return id;
}

void printArray(char *array[], size_t size) {
	for(int i = 0; i < size; i++) {
		printf("%s\n", array[i]);
	}
}

char *getStringWithIntValue(char string[], int number) {

}

void **getSpecifiedDesktopWindowIds(FILE *allIds, char specified, int countOfallIds) {
	char rawIdLine[200];
	char **specifiedDesktopIds = malloc(countOfallIds * sizeof(char*));
	int index = 0;

	while(fgets(rawIdLine, 200, allIds)) {
		if(specified == rawIdLine[12]) {
			specifiedDesktopIds[index++] = getWindowId(rawIdLine);
		}
	}

	printArray(specifiedDesktopIds, 3);

	return specifiedDesktopIds;
}

int main(int argc, char *argv[]) {
	FILE *f = popen("wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d", "r");
	FILE *w = popen("wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | wc -l", "r");
	FILE *c = popen("wmctrl -d | grep '*' | cut -c 1", "r");
	char *a = "wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | grep '^.\\{12\\}'";
	char *end = "'^.\\{12\\}'";

	int count = 0;

	int s = getWindowsNumber(w);
	int current = getWindowsNumber(c);
	//char *specified = argv[1];

	while(a[count] != '\0') count++;

	char full[count + 2];

	for(int c = 0; c < count; c++) {
		if(c == count - 1) {
			full[c] = current + '0';
			full[c + 1] = a[c];
		} else {
			full[c] = a[c];
		}
	}

	printf("%s\n", full);

	for(int c = 0; c < count + 1; c++) {
		printf("%c", full[c]);
	}

	FILE *all = popen(full, "r");

	char buffer[20];

	while(fgets(buffer, 20, all)) {
	 	
	 	printf("%s\n", buffer);
    }

	char *ids[s];

    char singleId[100];
    int index = 0;

    while(fgets(singleId, 100, f)) {
	 	
	 	if (current + '0' == singleId[12]) {
    		ids[index++] = getWindowId(singleId);
    	}
    }

   fclose(f);

   //char **selected = getSpecifiedDesktopWindowIds(f, current + '0', s);

   printArray(ids, 3);
   //printf("specified: %s\n", specified);
}