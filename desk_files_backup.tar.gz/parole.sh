parole

process_id=$(pidof parole)
notify-send $process_id

window_info=$(wmctrl -l -p | grep "$process_id" | tail -1)
window_id=${window_info:0:10}

transset -i $window_id 0.7