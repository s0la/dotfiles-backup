#include<stdio.h>
#include<stdlib.h>

void read(FILE *command) {
	char *buffer = 0;
	int length;

	fseek (command, 0, SEEK_END);
	length = ftell(command);
	
	

	printf("%d\n", length);
}

int main() {
	FILE *command = fopen("/home/sola/Desktop/file_for_count", "r");//popen("wmctrl -l | wc -l", "rb");

	read(command);
}