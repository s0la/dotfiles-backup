#!/bin/bash

~/Documents/scripts/general/sh/hide.sh $1
~/Documents/scripts/general/sh/show.sh $2 $3 $4