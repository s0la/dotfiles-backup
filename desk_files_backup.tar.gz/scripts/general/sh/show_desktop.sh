xdotool keydown ctrl keydown alt key d
xdotool keyup ctrl keyup alt