xfconf-query -c xfwm4 -p /general/margin_bottom -s $1
xfconf-query -c xfce4-panel -p /panels/panel-1/autohide-behavior -s $2