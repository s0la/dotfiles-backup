thunar $1
Documents/scripts/general/sh/make_transparent.sh 0.88