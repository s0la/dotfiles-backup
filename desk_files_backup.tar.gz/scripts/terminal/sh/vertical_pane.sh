xdotool keydown ctrl keydown b keydown shift keydown 5
xdotool keyup ctrl keyup b keyup shift keyup 5