#!/bin/bash

Documents/scripts/general/sh/shift.sh 3 1
Documents/scripts/parole/sh/parole.sh