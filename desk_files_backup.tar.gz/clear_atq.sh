for j in "$(atq)"; do
	atrm $(echo "$j" | grep -o "^\S*")
done