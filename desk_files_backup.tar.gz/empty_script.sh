current_num=0
current_desk=$(wmctrl -d | grep '*' | cut -c 1)
p_index=0
c_index=0

while read line;do
	if [ "${line:12:1}" == "$current_num" ]; then windows[${#windows[*]}]=${line:0:10}; fi
	
done <<< "$(wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | grep "^.\{12\}$current_num")"

function is_window_hidden {
	if [ -n "$(xwininfo -all -id $1 | grep -v 'xfce4-panel' | grep 'Hidden')" ]; then
		 # var=$($2)
		 # echo "$var"
		 #$($2) 
		 eval $2
	fi
}

for w in ${windows[@]}; do
	echo $w

	is_window_hidden $w "echo 'xdotool windowminimize $w' >> ~/Desktop/minimized_windows.txt"
done