#include<stdio.h>
#include<stdlib.h>

int getWindowsNumber(FILE *w) {

	char line[2];
	int size;

	while(fgets(line, 2, w) != NULL) {

	 	sscanf (line, "%d", &size);
   }

   return size;
}

char *getWindowId(char line[]) {

	char *id;

	id = malloc(10 * sizeof(char));

	for (int i = 0; i < 10; i++) {
		id[i] = line[i];
	}

	return id;
}

void printArray(char *array[], size_t size) {
	for(int i = 0; i < size; i++) {
		printf("%s\n", array[i]);
	}
}

int main() {
	FILE *f = popen("wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d", "r");
	FILE *w = popen("wmctrl -l | grep -v 'xfce4-panel' | grep -v 'plank' | sed 1d | wc -l", "r");

	int s = getWindowsNumber(w);
	char *ids[s];

    char singleId[200];

    char line[12];
    int index = 0;

    while(fgets(singleId, 200, f)) {

    	printf("%s\n", singleId);
    }

   fclose(f);

   //printArray(ids, sizeof(ids) / sizeof(*ids));
}